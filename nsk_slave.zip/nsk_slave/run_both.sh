#!/bin/zsh
# 并行运行 GUI(作为TCP服务器) 和 tcp_test_client.py，并在退出时清理后台进程

set -u

script_dir="$(cd "$(dirname "$0")" && pwd)"
gui="$script_dir/test.py"
client="$script_dir/tcp_test_client.py"

if [[ ! -f "$client" ]] || [[ ! -f "$gui" ]]; then
  echo "找不到脚本：$client 或 $gui"
  exit 1
fi

# 先启动 GUI（后台），在界面选择“网络”并点击连接以启动服务器
python3 "$gui" &
gui_pid=$!
echo "GUI 已启动，PID=$gui_pid"
sleep 2

cleanup() {
  echo "正在停止 GUI (PID=$gui_pid)…"
  kill $gui_pid 2>/dev/null || true
}
trap cleanup EXIT INT TERM

# 启动客户端（前台）
python3 "$client"
