import socket
import time
from datetime import datetime

HOST = "127.0.0.1"
PORT = 9000

# 简单的本地TCP测试服务器：接受一个连接并周期性发送数据
# 运行后，在你的GUI选择“网络”模式并连接到 127.0.0.1:9000

def run_server(host: str = HOST, port: int = PORT):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((host, port))
        s.listen(1)
        print(f"[{datetime.now().strftime('%H:%M:%S')}] TCP server listening on {host}:{port}")
        conn, addr = s.accept()
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Client connected from {addr}")
        with conn:
            try:
                i = 0
                while True:
                    # 每秒发送一帧测试数据（同时包含ASCII与二进制示例）
                    text = f"Hello {i}"
                    payload = b"\xAA\x55" + text.encode("utf-8") + b"\x0D\x0A"
                    conn.sendall(payload)
                    print(f"[{datetime.now().strftime('%H:%M:%S')}] Sent: {payload!r}")
                    i += 1
                    time.sleep(1)
            except KeyboardInterrupt:
                print("Interrupted, shutting down.")
            except Exception as e:
                print(f"Error: {e}")

if __name__ == "__main__":
    run_server()
