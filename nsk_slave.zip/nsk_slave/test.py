import tkinter as tk
from tkinter import ttk
import json
import threading
import queue
import time
import socket
from datetime import datetime
import os
try:
	import serial
	from serial.tools import list_ports
except Exception:
	serial = None
	list_ports = None

root = tk.Tk()
root.title("Protocol Slave Simulator")

# 顶部：连接配置
conn_frame = ttk.LabelFrame(root, text="连接配置")
conn_frame.pack(fill="x", padx=10, pady=5)

ttk.Label(conn_frame, text="模式:").pack(side="left")
mode_combo = ttk.Combobox(conn_frame, values=["串口", "网络"], width=6)
mode_combo.set("串口")
mode_combo.pack(side="left", padx=5)

serial_frame = ttk.Frame(conn_frame)
tcp_frame = ttk.Frame(conn_frame)

# 串口子框
ttk.Label(serial_frame, text="串口:").pack(side="left")
port_combo = ttk.Combobox(serial_frame, values=[], width=12)
port_combo.pack(side="left", padx=5)
refresh_btn = ttk.Button(serial_frame, text="扫描")
refresh_btn.pack(side="left", padx=5)

ttk.Label(serial_frame, text="波特率:").pack(side="left")
baud_entry = ttk.Entry(serial_frame, width=8)
baud_entry.insert(0, "115200")
baud_entry.pack(side="left", padx=5)

# 网络子框
ttk.Label(tcp_frame, text="IP:").pack(side="left")
ip_entry = ttk.Entry(tcp_frame, width=12)
ip_entry.insert(0, "127.0.0.1")
ip_entry.pack(side="left", padx=5)

ttk.Label(tcp_frame, text="端口:").pack(side="left")
tcp_port_entry = ttk.Entry(tcp_frame, width=6)
tcp_port_entry.insert(0, "9000")
tcp_port_entry.pack(side="left", padx=5)

# 初始显示串口子框
serial_frame.pack(side="left")

connect_btn = ttk.Button(conn_frame, text="连接")
connect_btn.pack(side="left", padx=5)

def on_save_config():
	try:
		data = {}
		if os.path.exists("cmd.json"):
			with open("cmd.json", "r", encoding="utf-8") as f:
				data = json.load(f)
		cmds = data.get("commands", [])
		for i, entry in enumerate(cmd_entries):
			if i < len(cmds):
				max_len = entry.get("resp_data_len")
				val = entry.get("resp_hex").get()
				cmds[i]["resp_hex"] = sanitize_hex_input(val, max_len if isinstance(max_len, int) else None)
		data["commands"] = cmds
		with open("cmd.json", "w", encoding="utf-8") as f:
			json.dump(data, f, ensure_ascii=False, indent=2)
		log_queue.put("配置已保存到 cmd.json")
	except Exception as e:
		log_queue.put(f"保存失败: {e}")

save_btn = ttk.Button(conn_frame, text="保存配置", command=on_save_config)
save_btn.pack(side="right", padx=5)

# 中部：命令配置（根据 cmd.json 动态生成）- 增加滚动，单列布局
cmd_container = ttk.LabelFrame(root, text="命令配置")
cmd_container.pack(fill="both", expand=True, padx=10, pady=5)

# 使用 Canvas + Scrollbar 实现可滚动区域
cmd_canvas = tk.Canvas(cmd_container, highlightthickness=0)
cmd_scrollbar = ttk.Scrollbar(cmd_container, orient="vertical", command=cmd_canvas.yview)
cmd_canvas.configure(yscrollcommand=cmd_scrollbar.set)
cmd_canvas.pack(side="left", fill="both", expand=True)
cmd_scrollbar.pack(side="right", fill="y")

# 固定一个较友好的显示高度，避免挤占日志区域
cmd_canvas.configure(height=300, yscrollincrement=20)

# 真正放控件的内层 Frame
inner_frame = ttk.Frame(cmd_canvas)
cmd_canvas.create_window((0, 0), window=inner_frame, anchor="nw")

# 鼠标滚轮支持（macOS/Windows/Linux）
def _on_mousewheel(event):
	try:
		delta = -1 if event.delta > 0 else 1
		if abs(event.delta) >= 120:
			delta = -int(event.delta / 120)
		cmd_canvas.yview_scroll(delta, "units")
	except Exception:
		pass

def _bind_wheel(_):
	cmd_canvas.bind_all("<MouseWheel>", _on_mousewheel)

def _unbind_wheel(_):
	cmd_canvas.unbind_all("<MouseWheel>")

cmd_canvas.bind("<Enter>", _bind_wheel)
cmd_canvas.bind("<Leave>", _unbind_wheel)
cmd_canvas.bind("<Button-4>", lambda e: cmd_canvas.yview_scroll(-1, "units"))
cmd_canvas.bind("<Button-5>", lambda e: cmd_canvas.yview_scroll(1, "units"))

_scrollregion_scheduled = {"flag": False}

def _update_scrollregion(event=None):
	if _scrollregion_scheduled["flag"]:
		return
	_scrollregion_scheduled["flag"] = True
	def _do():
		try:
			cmd_canvas.configure(scrollregion=cmd_canvas.bbox("all"))
		finally:
			_scrollregion_scheduled["flag"] = False
	root.after_idle(_do)

inner_frame.bind("<Configure>", _update_scrollregion)

# 载入 JSON
commands = []
try:
	with open("cmd.json", "r", encoding="utf-8") as f:
		data = json.load(f)
		commands = data.get("commands", [])
except Exception:
	commands = []

# 保存每条命令的设置变量
cmd_settings = {}
cmd_entries = []  # 与 commands 顺序一致，用于保存回写 JSON

def sanitize_hex_input(s: str, max_len: int | None) -> str:
	if s is None:
		s = ""
	hex_chars = "0123456789abcdefABCDEF"
	filtered = "".join(ch for ch in s if ch in hex_chars)
	filtered = filtered.upper()
	usable_len = len(filtered) - (len(filtered) % 2)
	if usable_len < 0:
		usable_len = 0
	filtered = filtered[:usable_len]
	pairs = [filtered[i:i+2] for i in range(0, len(filtered), 2)]
	if isinstance(max_len, int) and max_len > 0:
		pairs = pairs[:max_len]
	return " ".join(pairs)

# 单列布局：每行一个命令框
inner_frame.columnconfigure(0, weight=1)

for idx, cmd in enumerate(commands):
	name = cmd.get("name", f"CMD {idx+1}")
	cmd_id = cmd.get("cmd_id", "")
	resp_id = cmd.get("resp_id", "")

	row = idx
	col = 0

	frame = ttk.Frame(inner_frame)
	frame.grid(row=row, column=col, padx=8, pady=6, sticky="ew")
	frame.columnconfigure(0, weight=0)
	frame.columnconfigure(1, weight=1)
	frame.columnconfigure(2, weight=0)
	frame.columnconfigure(3, weight=1)

	# 顶部信息行：名称/CMD/回复ID/长度（一行显示）
	resp_len = cmd.get("resp_data_len", "-")
	info_text = f"{name}   [命令: {cmd_id}    回复: {resp_id}    长度: {resp_len}]"
	ttk.Label(frame, text=info_text).grid(row=0, column=0, columnspan=4, padx=6, pady=(2, 6), sticky="w")

	# 延迟时间（毫秒）
	ttk.Label(frame, text="延迟(ms):").grid(row=1, column=0, padx=6, pady=4, sticky="w")
	delay_var = tk.IntVar(value=0)
	delay_entry = ttk.Entry(frame, textvariable=delay_var, width=8)
	delay_entry.grid(row=1, column=1, padx=6, pady=4, sticky="w")

	# 几次后开始回复（从第 N 次请求起才回复）
	ttk.Label(frame, text="几次后开始回复:").grid(row=1, column=2, padx=12, pady=4, sticky="w")
	start_after_var = tk.IntVar(value=0)
	start_after_spin = tk.Spinbox(frame, from_=0, to=100, textvariable=start_after_var, width=6)
	start_after_spin.grid(row=1, column=3, padx=6, pady=4, sticky="w")

	# 回复内容（HEX，可编辑）
	given_hex = cmd.get("resp_hex", "")
	max_len_bytes = resp_len if isinstance(resp_len, int) else None
	sanitized_hex = sanitize_hex_input(given_hex, max_len_bytes)
	if not sanitized_hex and isinstance(resp_len, int) and resp_len > 0:
		sanitized_hex = " ".join(["00"] * resp_len)
	resp_hex_var = tk.StringVar(value=sanitized_hex)
	ttk.Label(frame, text="回复内容(HEX):").grid(row=2, column=0, padx=6, pady=4, sticky="w")
	resp_hex_entry = ttk.Entry(frame, textvariable=resp_hex_var, width=50)
	resp_hex_entry.grid(row=2, column=1, columnspan=3, padx=6, pady=4, sticky="ew")

	def _on_hex_focus_out(event=None, var=resp_hex_var, max_len=max_len_bytes):
		var.set(sanitize_hex_input(var.get(), max_len))

	resp_hex_entry.bind("<FocusOut>", _on_hex_focus_out)

	# 存储变量引用，后续逻辑可读取这些值
	cmd_settings[cmd_id] = {
		"name": name,
		"delay_ms": delay_var,
		"start_after": start_after_var,
		"resp_id": resp_id,
		"resp_data_len": resp_len,
		"resp_hex": resp_hex_var,
	}

	cmd_entries.append({
		"index": idx,
		"resp_hex": resp_hex_var,
		"resp_data_len": resp_len,
	})

# 底部：日志区域
log_text = tk.Text(root, height=10, width=50)
log_text.pack(fill="both", expand=True, padx=10, pady=5)

########################
# 串口管理与日志
########################

log_queue = queue.Queue()

def append_log(msg: str):
	try:
		ts = datetime.now().strftime('%H:%M:%S.%f')
		log_text.insert("end", f"[{ts}] {msg}\n")
		log_text.see("end")
	except Exception:
		pass

class SerialManager:
	def __init__(self):
		self.ser = None
		self.reader = None
		self.stop_event = threading.Event()

	def is_connected(self):
		return self.ser is not None and self.ser.is_open

	def connect(self, port: str, baud: int):
		if serial is None:
			log_queue.put("未安装 pyserial，无法连接串口。请先安装：pip install pyserial")
			return False
		try:
			self.ser = serial.Serial(port=port, baudrate=baud, timeout=0.2)
			self.stop_event.clear()
			self.reader = threading.Thread(target=self._read_loop, daemon=True)
			self.reader.start()
			return True
		except Exception as e:
			log_queue.put(f"连接失败: {e}")
			self.ser = None
			return False

	def disconnect(self):
		try:
			self.stop_event.set()
			if self.reader and self.reader.is_alive():
				self.reader.join(timeout=1.0)
		except Exception:
			pass
		try:
			if self.ser and self.ser.is_open:
				self.ser.close()
		except Exception:
			pass
		self.ser = None
		self.reader = None

	def _read_loop(self):
		while not self.stop_event.is_set():
			try:
				if self.ser and self.ser.is_open:
					data = self.ser.read(1024)
					if data:
						# 显示为十六进制
						hex_str = " ".join(f"{b:02X}" for b in data)
						log_queue.put(f"RX: {hex_str}")
				time.sleep(0.02)
			except Exception as e:
				log_queue.put(f"读取错误: {e}")
				time.sleep(0.2)
				break

serial_mgr = SerialManager()

class TcpManager:
	def __init__(self):
		self.listen_sock = None
		self.conn = None
		self.accept_thread = None
		self.stop_event = threading.Event()

	def is_connected(self):
		# 表示服务器已启动
		return self.listen_sock is not None

	def start_server(self, host: str, port: int):
		try:
			self.listen_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			self.listen_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
			self.listen_sock.bind((host, port))
			self.listen_sock.listen(1)
			self.listen_sock.settimeout(0.5)
			self.stop_event.clear()
			self.accept_thread = threading.Thread(target=self._accept_loop, daemon=True)
			self.accept_thread.start()
			log_queue.put(f"TCP服务已启动: {host}:{port}，等待客户端连接…")
			return True
		except Exception as e:
			log_queue.put(f"TCP服务启动失败: {e}")
			self.listen_sock = None
			return False

	def stop_server(self):
		try:
			self.stop_event.set()
			if self.accept_thread and self.accept_thread.is_alive():
				self.accept_thread.join(timeout=1.0)
		except Exception:
			pass
		try:
			if self.conn:
				try:
					self.conn.shutdown(socket.SHUT_RDWR)
				except Exception:
					pass
				self.conn.close()
		except Exception:
			pass
		try:
			if self.listen_sock:
				self.listen_sock.close()
		except Exception:
			pass
		self.conn = None
		self.listen_sock = None
		self.accept_thread = None

	def _accept_loop(self):
		while not self.stop_event.is_set():
			try:
				try:
					conn, addr = self.listen_sock.accept()
				except socket.timeout:
					continue
				self.conn = conn
				self.conn.settimeout(0.2)
				log_queue.put(f"TCP客户端已连接: {addr}")
				# 读循环（直到客户端断开或服务停止）
				while not self.stop_event.is_set():
					try:
						try:
							data = self.conn.recv(1024)
						except socket.timeout:
							data = b""
						if data:
							hex_str = " ".join(f"{b:02X}" for b in data)
							log_queue.put(f"TCP RX: {hex_str}")
						else:
							# 客户端可能断开
							time.sleep(0.05)
							# 检查连接是否仍然有效（简单处理：空数据持续则认为断开）
							# 若需要更严格判断，可在此加入心跳或错误侦测
					except Exception as e:
						log_queue.put(f"TCP读取错误: {e}")
						break
				try:
					self.conn.close()
				except Exception:
					pass
				self.conn = None
				log_queue.put("TCP客户端已断开，继续等待新客户端…")
			except Exception as e:
				log_queue.put(f"TCP接受错误: {e}")
				time.sleep(0.2)

tcp_mgr = TcpManager()

connected_mode = None  # None / 'serial' / 'tcp'

def update_conn_mode(event=None):
	mode = mode_combo.get()
	if connected_mode:
		return
	# 先隐藏两个子框，再显示对应模式
	try:
		serial_frame.pack_forget()
	except Exception:
		pass
	try:
		tcp_frame.pack_forget()
	except Exception:
		pass
	if mode == "串口":
		serial_frame.pack(side="left")
	else:
		tcp_frame.pack(side="left")

def scan_ports():
	ports = []
	try:
		if list_ports is not None:
			ports = [p.device for p in list_ports.comports()]
	except Exception as e:
		append_log(f"扫描串口失败: {e}")
	port_combo["values"] = ports
	if ports:
		port_combo.set(ports[0])

def on_connect_click():
	global connected_mode
	# 如果已连接则断开当前模式
	if connected_mode == 'serial' and serial_mgr.is_connected():
		serial_mgr.disconnect()
		connected_mode = None
		connect_btn.configure(text="连接")
		port_combo.configure(state="normal")
		baud_entry.configure(state="normal")
		mode_combo.configure(state="normal")
		log_queue.put("已断开串口连接")
		update_conn_mode()
		return
	if connected_mode == 'tcp' and tcp_mgr.is_connected():
		tcp_mgr.stop_server()
		connected_mode = None
		connect_btn.configure(text="连接")
		ip_entry.configure(state="normal")
		tcp_port_entry.configure(state="normal")
		mode_combo.configure(state="normal")
		log_queue.put("已断开TCP连接")
		update_conn_mode()
		return

	# 开始连接
	mode = mode_combo.get()
	if mode == "串口":
		port = port_combo.get().strip()
		try:
			baud = int(baud_entry.get())
		except Exception:
			baud = 9600
		if not port:
			log_queue.put("请先选择或输入串口端口")
			return
		ok = serial_mgr.connect(port, baud)
		if ok:
			connected_mode = 'serial'
			connect_btn.configure(text="断开")
			port_combo.configure(state="disabled")
			baud_entry.configure(state="disabled")
			mode_combo.configure(state="disabled")
			log_queue.put(f"串口已连接: {port} @ {baud}")
	else:
		host = ip_entry.get().strip() or "127.0.0.1"
		try:
			tcp_port = int(tcp_port_entry.get())
		except Exception:
			tcp_port = 9000
		ok = tcp_mgr.start_server(host, tcp_port)
		if ok:
			connected_mode = 'tcp'
			connect_btn.configure(text="停止")
			ip_entry.configure(state="disabled")
			tcp_port_entry.configure(state="disabled")
			mode_combo.configure(state="disabled")
			log_queue.put(f"TCP服务运行中: {host}:{tcp_port}")

def poll_logs():
	try:
		while True:
			msg = log_queue.get_nowait()
			append_log(msg)
	except queue.Empty:
		pass
	root.after(100, poll_logs)

def on_close():
	try:
		serial_mgr.disconnect()
		tcp_mgr.stop_server()
	except Exception:
		pass
	root.destroy()

# 绑定按钮事件
refresh_btn.configure(command=scan_ports)
connect_btn.configure(command=on_connect_click)
mode_combo.bind("<<ComboboxSelected>>", update_conn_mode)

# 初始扫描一次
scan_ports()
update_conn_mode()

# 启动日志轮询
root.after(100, poll_logs)

root.protocol("WM_DELETE_WINDOW", on_close)
root.mainloop()