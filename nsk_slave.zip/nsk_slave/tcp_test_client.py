import socket
import time
from datetime import datetime

HOST = "127.0.0.1"
PORT = 9000

# 简单的本地TCP客户端：连接到你的GUI服务器并周期性发送数据
# 运行顺序：先在GUI选择“网络”，启动服务器（连接按钮会变为“停止”），再运行本脚本。

def run_client(host: str = HOST, port: int = PORT):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(5)
        s.connect((host, port))
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Connected to {host}:{port}")
        try:
            i = 0
            while True:
                text = f"Hello {i}"
                payload = b"\xAA\x55" + text.encode("utf-8") + b"\x0D\x0A"
                s.sendall(payload)
                print(f"[{datetime.now().strftime('%H:%M:%S')}] Sent: {payload!r}")
                i += 1
                time.sleep(1)
        except KeyboardInterrupt:
            print("Interrupted, shutting down.")
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    run_client()
